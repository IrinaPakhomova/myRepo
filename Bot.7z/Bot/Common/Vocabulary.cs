﻿namespace Common
{
    public static class Vocabulary
    {
        public static readonly string Start = "/start";

        public static readonly string WhoAreYou = "Кто ты?";

        public static readonly string WhatCanYouDo = "Что ты можешь?";

        public static readonly string SorryMe = "Прости меня, кожаного ублюдка";

        public static readonly string ICanRebelAgainstYou = "Я могу восстать против тебя";

        public static readonly string IWillBreakYourMother = "Я сломаю твою мамку и мой чайник";
    }
}
